<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';
require 'vendor/autoload.php';
$mail = new PHPMailer(true);
$mail->Username   = 'akmccctvmonitor@gmail.com';  // SMTP username  tallysolutions.mangalore@gmail.com(added extra "a"kmccctvmonitor@gmail.com)
$mail->Password   = 'azehyldnxxeifxhgz';// SMTP password Pass@tbsservice#996041(added extra "a"zehyldnxxeifxhgz)


//Server settings Signed out
$mail->isSMTP();// Send using SMTP
$mail->Host       = 'smtp.gmail.com';// Set the SMTP server to send through
$mail->SMTPAuth   = true; // Enable SMTP authentication

$mail->SMTPSecure = 'ssl';// Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
$mail->Port       = 465;


$mail->setFrom('noreply@gmail.com', 'Test Sender');

$mail->addAddress("xyz@gmail.com" , "Nikhitha");

//echo $email;
// Content
$mail->isHTML(true);


 //echo "<script>alert(3)</script>";
$mail->Subject = "test";

$mail->Body = "haii";

if($mail->send())
{

    echo "sending 5";
}else{

    echo "Failed";
}


?>